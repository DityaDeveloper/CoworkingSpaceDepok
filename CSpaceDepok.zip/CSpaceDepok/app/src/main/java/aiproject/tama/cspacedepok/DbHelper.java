package aiproject.tama.cspacedepok;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import static aiproject.pusloc.puslocdepok.R.drawable.pusloc;


public class DbHelper extends SQLiteOpenHelper {
    final static String DB_NAME = "db_puskesmas";
    public DbHelper(Context context) {
        super(context, DB_NAME, null, 1);
        // TODO Auto-generated constructor stub
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "CREATE TABLE IF NOT EXISTS puskesmas(_id INTEGER PRIMARY KEY AUTOINCREMENT, nama TEXT, alamat TEXT, no_tlpn NUMERIC, descripsi TEXT,latitude Double,longtitude Double, img BLOB)";
        db.execSQL(sql);

        ContentValues values = new ContentValues();
        //copy puskesmas disini
        values.put("_id", "111");
        values.put("nama", "Puskesmas Kecamatan Beji ");
        values.put("alamat", "Jl. Bambon Raya No.7B Rt.01/01, Beji Timur, Beji, Kota Depok");
        values.put("no_tlpn", "(021) 7757033");
        values.put("descripsi","Puskesmas Beji Merupakan ...");
        values.put("latitude","-6.376138");
        values.put("longtitude","106.821667");
        values.put("img",pusloc);
        db.insert("puskesmas","_id", values);


    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS puskesmas");
        onCreate(db);

    }
}
